export const ways = [
  {
    title: "Фильтрация информации и технологий",
    description: "12345",
  },
  {
    title: "Формат",
    description: "вапвапр",
  },
  {
    title: "Применение разных форматов",
    description: "лголыролвалоывыв",
  },
];

export const differences = {
  way: "Узконаправленный подъод",
  easy: "Доступность обучения",
  program: "Концентрация знаний",
};
